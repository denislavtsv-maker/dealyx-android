# Как да компилираш Dealyx APK през GitHub от телефона

1. Създай GitHub repository (може Private) с име `dealyx-android`.
2. Разархивирай този ZIP на телефона или компютър. Качи СЪДЪРЖАНИЕТО на архива в корена на repository, така че `.github/workflows/android-apk.yml` да е на правилното място. Не качвай ZIP като единствен файл.
3. Увери се, че файловете са в основната папка: `package.json`, `capacitor.config.ts`, `assets/`, `www/`, `.github/`.
4. Отвори repository → Actions. Ако GitHub покаже предупреждение за workflows, натисни разрешението да ги активираш.
5. Отвори workflow `Build Dealyx Android APK` → `Run workflow` → `Run workflow`.
6. Изчакай зелената отметка. Отвори успешното изпълнение и свали artifact `dealyx-debug-apk`.
7. Разархивирай изтегления artifact ZIP и инсталирай `app-debug.apk` на Android. Ако телефонът поиска, разреши инсталиране от този източник.

## Важно
- Това workflow прави **debug APK за тест**, не подписан production APK за Google Play.
- Приложението е Capacitor WebView към `https://dealyx.online`; използва живия сайт и неговия backend. Някои външни вход/плащане/качване потоци може да се държат различно в WebView и трябва да се тестват.
- Този ZIP не съдържа тайни или ключове. Не добавяй Stripe secret keys или пароли в GitHub.
- iOS компилация не може да се направи на този Ubuntu workflow; тя изисква отделен macOS/Xcode workflow.
