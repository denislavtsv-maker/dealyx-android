# DEALYX App — Android + iPhone (Capacitor source)

Този архив е изходният проект за Android/iOS приложение, което използва съществуващия сайт `https://dealyx.online` и неговия бекенд. Така акаунтите, обявите, Community, съобщенията и API остават общи.

## Важно
Това е проект за компилиране и преглед, а не подписан APK/AAB или IPA. За финален публичен релийз са нужни Android/iOS native проекти, тестове на реални устройства, app icons/splash screens, Apple Developer и Google Play Console настройки и подписване. Прост remote-webview wrapper може да не бъде одобрен от магазините; преди публикуване трябва да се прегледат правилата и да се пакетира тестван локален frontend.

## Подготовка (компютър с Node.js LTS)
1. Инсталирай Node.js LTS.
2. В тази папка изпълни `npm install`.
3. Изпълни `npm run add:android` и `npm run add:ios` (iOS изисква macOS + Xcode).
4. `npm run sync`.
5. `npm run android` отваря Android Studio; `npm run ios` отваря Xcode.

Текущата конфигурация отваря живия сайт, за да може да се прегледа мобилното поведение с реалния бекенд. Тествай login, profile editing, Community polls, marketplace, uploads, payment redirects, back navigation, keyboard and push notifications before release. Push notifications require a separate APNs/FCM setup and are not enabled by this starter.

## Security
Не слагай Stripe secret keys, database passwords или други сървърни тайни в приложението. Те трябва да останат само в PHP API конфигурацията на хостинга.
